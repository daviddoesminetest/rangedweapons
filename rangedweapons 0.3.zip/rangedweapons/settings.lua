-- change "true" to "false" in order to disable a feature, or 
-- "false" to "true" to enable it

explosives = true
javelins = true
shurikens = true
handguns = true
shotguns = true
rifles = true
magnums_and_revolvers = true
machine_pistols = true
sub_machineguns = true
assault_rifles = true
power_weapons = true
glass_breaking = true
door_breaking = true
heavy_machineguns = true
minigun_aswell = true

 